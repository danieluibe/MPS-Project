###############################
# Generate Cluster Fearures   
# input: user/exchange/fact parquet data 
# output: Features
###############################

from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, Row
from operator import add
from pyspark.sql.functions import desc

"""
Constants
"""

APP_NAME = "Generate Cluster Fearures" # application name
EXCHANGE_ADDR = "maprfs:///dl.dev/data/fpi/processed/exchange/*.parquet" # location of dataset in Unix file path
USERS_ADDR = "maprfs:///dl.dev/data/fpi/processed/users/*.parquet"
FACT_ADDR = "maprfs:///dl.dev/data/fpi/processed/fact/*.parquet"
NUM = 20000 # show how many 3rd parties


def main(sc):
    """
    Load dataset
    """
    sqlContext = SQLContext(sc)
    exchange_table = sqlContext.read.parquet(EXCHANGE_ADDR)
    users_table = sqlContext.read.parquet(USERS_ADDR)
    fact_table = sqlContext.read.parquet(FACT_ADDR)
    
    """
    Join dataset
    User: user_key, user_id, organization_id
    Exchange: exchange_key, exchange_id, organization_id
    Fact: user_key, exchange_key
    method: investigating the users in user table whose organization ids are different 
              from the organization ids of their corresponding exchange.
    """
    # select useful data
    users = users_table[["user_key","organization_id"]].toDF("user_key","org_id_user")
    exchange = exchange_table[["exchange_key","organization_id"]].toDF("exchange_key","org_id_ex")
    fact = fact_table[["user_key", "exchange_key"]]
    
    # join dataset to find pair
    users_fact = users.join(fact,users.user_key==fact.user_key,"left")
    users_ex = users_fact.join(exchange, users_fact.exchange_key == exchange.exchange_key,"left")
    pairs = users_ex.filter(users_ex["org_id_user"]!=users_ex["org_id_ex"])[["org_id_user","org_id_ex"]].withColumnRenamed("org_id_user", "usr").withColumnRenamed("org_id_ex", "ex")

    # contract count
    contract_count = pairs.groupBy("usr","ex").count().withColumnRenamed("count", "contract_count")

    # client count
    client_count = contract_count.groupBy("usr").agg({"ex":"count","contract_count":"sum"})

    # find third parties and their user count
    third_parties = contract_count[["usr"]].subtract(contract_count[["ex"]]).distinct()
    users_org = users.groupBy("org_id_user").count().withColumnRenamed("count", "user_count")
    third_parties_count = third_parties.join(users_org, users_org.org_id_user == third_parties.usr, "left")
    final_count = third_parties_count.join(client_count, client_count.usr == third_parties_count.usr,"left")

    # combine features
    features = final_count[["org_id_user","user_count","sum(contract_count)","count(ex)"]].toDF("org_id","user_count","contract_count","client_count")
    
    # print to csv (could be saved if have)
    temp = features.sample(False, 0.05, seed=0).limit(NUM).map(lambda x: x).collect()
    print ",".join(features.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)




















if __name__ == "__main__":

    # Configure Spark
    conf = SparkConf().setAppName(APP_NAME).set("spark.cores.max", "35")
    conf = conf.setMaster("spark://mapr-dev03.sncrbda.dev.vacum-np.sncrcorp.net:7077")
    sc    = SparkContext(conf=conf)

    # Execute Main functionality
    main(sc)