###############################
# Count 3rd Party names      
# input: user/exchange/fact parquet data 
# output: Find all 3rd Parties
###############################

from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, Row
from operator import add
from pyspark.sql.functions import desc

"""
Constants
"""

APP_NAME = "Count 3rd Party names" # application name
EXCHANGE_ADDR = "maprfs:///dl.dev/data/fpi/processed/exchange/*.parquet" # location of dataset in Unix file path
USERS_ADDR = "maprfs:///dl.dev/data/fpi/processed/users/*.parquet"
FACT_ADDR = "maprfs:///dl.dev/data/fpi/processed/fact/*.parquet"
NUM = 20 # show how many 3rd parties

"""
Helper functions
"""
# convert data to string and joined with commas
def toCSVLine(data):
    return ','.join(str(d) for d in data) 

"""
Main function
"""
def main(sc):

    """
    Load dataset
    """
    sqlContext = SQLContext(sc)
    exchange_table = sqlContext.read.parquet(EXCHANGE_ADDR)
    users_table = sqlContext.read.parquet(USERS_ADDR)
    fact_table = sqlContext.read.parquet(FACT_ADDR)
    print "-------successfully load dataset----------"


    
    """
    Join dataset
    User: user_key, user_id, organization_id
    Exchange: exchange_key, exchange_id, organization_id
    Fact: user_key, exchange_key
    method: investigating the users in user table whose organization ids are different 
              from the organization ids of their corresponding exchange.
    """
    users = users_table[["user_key","organization_id"]].toDF("user_key","org_id_user")
    exchange = exchange_table[["exchange_key","organization_id"]].toDF("exchange_key","org_id_ex")
    fact = fact_table[["user_key", "exchange_key"]]
    
    print "-------successfully selected data----------"
    
    # left join user and fact
    users_fact = users.join(fact,users.user_key==fact.user_key,"left")
    # left join user_fact and exchange
    users_ex = users_fact.join(exchange, users_fact.exchange_key == exchange.exchange_key,"left")
    # select user_ex rows which have different org id
    contract_pairs = users_ex.filter(users_ex["org_id_user"]!=users_ex["org_id_ex"])[["org_id_user","org_id_ex"]].distinct()
    # filter 3rd parties because there sre clients in it 
    """
    third_parties = contract_pairs[["org_id_user"]].toDF("third_org_id_user")
    clients = contract_pairs[["org_id_ex"]]
    third_parties = third_parties.subtract(clients)
    """


    # dont eliminate clients (may contain clients) 
    third_parties = contract_pairs[["org_id_user"]].toDF("third_org_id_user")

    print "-------successfully joined data----------"
    

    """
    COUNT NUMBERS
    User count: count how many user_ids in one org (size of third parties)
    """
    
    # user count
    third_parties_count = third_parties[["third_org_id_user"]].groupBy("third_org_id_user").count().orderBy(desc("count")).limit(NUM)
    """
    print "--------user count of 3rd parties----------"
    temp = third_parties_count.map(lambda x: x).collect()
    print ",".join(third_parties_count.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)
    """
    
    """
    # client count
    clients = users_ex.filter(users_ex["org_id_user"]==users_ex["org_id_ex"])[["org_id_user"]]
    client_count = clients.groupBy("org_id_user").count().orderBy(desc("count"))
    print "--------user count of clients----------"
    temp = client_count.limit(NUM).map(lambda x: x).collect()
    print ",".join(client_count.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)
    """

    """
    # count how many distinct clients
    print "--------------clients num of 10 3rd parties-------------"
    third_parties_count = third_parties_count.limit(15)
    third_parties_conn = third_parties_count.join(contract_pairs, third_parties_count.third_org_id_user==contract_pairs.org_id_user,"left")[["org_id_user","org_id_ex"]]
    print third_parties_conn[["org_id_ex"]].distinct().count()

    print "--------------clients num of 15 3rd parties-------------"
    third_parties_count = third_parties_count.limit(10)
    third_parties_conn = third_parties_count.join(contract_pairs, third_parties_count.third_org_id_user==contract_pairs.org_id_user,"left")[["org_id_user","org_id_ex"]]
    print third_parties_conn[["org_id_ex"]].distinct().count()
    """




    third_parties_conn = third_parties_count.join(contract_pairs, third_parties_count.third_org_id_user==contract_pairs.org_id_user,"left")[["org_id_user","org_id_ex"]]

    #client_count = third_parties_conn[["org_id_ex"]].groupBy("org_id_ex").count().orderBy(desc("count")).limit(NUM)[["org_id_ex"]].toDF("client_org_id")
    #twoside_conn = client_count.join(third_parties_conn,client_count.client_org_id== third_parties_conn.org_id_ex,"left")[["org_id_user","org_id_ex"]]
    print "--------- going to print "+str(third_parties_conn.count())+" connections ------------"

    temp = third_parties_conn.map(lambda x: x).collect()
    print ",".join(third_parties_conn.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)
    
    """
    twoside_conn.show()

    temp = twoside_conn.map(lambda x: x).collect()
    print ",".join(twoside_conn.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)
    """
    print "---------------FINISHED------------------"
    
    


    """
    connections = users_ex[["org_id_ex","org_id_user"]].filter(users_ex["org_id_user"]!=users_ex["org_id_ex"])[["org_id_user","org_id_ex"]]
    connections_pairs = connections.distinct()
    print "--------connections of organizations----------"
    temp = connections_pairs.limit(NUM).map(lambda x: x).collect()
    print ",".join(connections_pairs.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)
    """








    # top client - count clients in exchange table
    #top_client = exchange[["org_id_ex"]].groupBy("org_id_ex").count().orderBy(desc("count"))
    #print "---------top client----------"
    #top_client.limit(20).show()












    #contracts_id = exchange_table[[columnName]].map(lambda p: (p,1))
    #contracts_count = contracts_id.reduceByKey(add)#.filter(lambda x:x[1]>10)
    #    sortedCount = contracts_count.sortBy(lambda x: -x[1]).collect()
        #print columnName
        #for item in sortedCount[:20]:
        #    print str(item[0].asDict()[columnName])+","+str(item[1])


        #lines = sortedCount.map(toCSVLine)
        #lines.saveAsTextFile("~/mapr/bda_lab_batch/bda/data/fpi/"+columnName+".csv")






  
  
if __name__ == "__main__":

    # Configure Spark
    conf = SparkConf().setAppName(APP_NAME)
    conf = conf.setMaster("spark://mapr-dev03.sncrbda.dev.vacum-np.sncrcorp.net:7077")
    sc    = SparkContext(conf=conf)

    # Execute Main functionality
    main(sc)
