###############################
# Count 3rd Party names      
# input: user/exchange/fact parquet data 
# output: Find all 3rd Parties
###############################

from pyspark import SparkConf, SparkContext
from pyspark.sql import SQLContext, Row
from operator import add
from pyspark.sql.functions import desc


#from pyspark.mllib.clustering import KMeans, KMeansModel
#from pyspark.mllib.linalg import DenseVector
#from pyspark.mllib.linalg import SparseVector
#from pyspark.mllib.linalg import Vectors

"""
Constants
"""

APP_NAME = "Generate Cluster Fearures" # application name
EXCHANGE_ADDR = "maprfs:///dl.dev/data/fpi/processed/exchange/*.parquet" # location of dataset in Unix file path
USERS_ADDR = "maprfs:///dl.dev/data/fpi/processed/users/*.parquet"
FACT_ADDR = "maprfs:///dl.dev/data/fpi/processed/fact/*.parquet"
NUM = 20000 # show how many 3rd parties

def main(sc):
    """
    Load dataset
    """
    sqlContext = SQLContext(sc)
    exchange_table = sqlContext.read.parquet(EXCHANGE_ADDR)
    users_table = sqlContext.read.parquet(USERS_ADDR)
    fact_table = sqlContext.read.parquet(FACT_ADDR)
    print "-------successfully load dataset----------"
    """
    Join dataset
    User: user_key, user_id, organization_id
    Exchange: exchange_key, exchange_id, organization_id
    Fact: user_key, exchange_key
    method: investigating the users in user table whose organization ids are different 
              from the organization ids of their corresponding exchange.
    """
    users = users_table[["user_key","organization_id"]].toDF("user_key","org_id_user")
    exchange = exchange_table[["exchange_key","organization_id"]].toDF("exchange_key","org_id_ex")
    fact = fact_table[["user_key", "exchange_key"]]
    
    print "-------successfully selected data----------"
    
    # left join user and fact
    users_fact = users.join(fact,users.user_key==fact.user_key,"left")
    # left join user_fact and exchange
    users_ex = users_fact.join(exchange, users_fact.exchange_key == exchange.exchange_key,"left")
    # select user_ex rows which have different org id
    contract_pairs = users_ex.filter(users_ex["org_id_user"]!=users_ex["org_id_ex"])[["org_id_user","org_id_ex"]].groupBy("org_id_user","org_id_ex").count().withColumnRenamed("count", "contract_count")
    print "contract pair numbers"
    print contract_pairs.count()

    # filter 3rd parties because there sre clients in it 
    third_parties = contract_pairs[["org_id_user"]].withColumnRenamed("org_id_user","org_id")
    clients = contract_pairs[["org_id_ex"]].withColumnRenamed("org_id_ex","org_id")
    third_parties = third_parties.subtract(clients).withColumnRenamed("org_id","third_org_id_user").distinct() #? will use colum name to subtract?
    third_parties_conn = third_parties.join(contract_pairs, contract_pairs.org_id_user == third_parties.third_org_id_user, "left")[["third_org_id_user","org_id_ex","contract_count"]]
    print "third parties column"
    print third_parties_conn.columns
    print "third parties num"
    print third_parties_conn.count()

    # get the connection with 3rd parties
    # third_org_id_user/ user_count/ client_count
    third_parties_count = third_parties_conn.groupBy("third_org_id_user").agg(sum("contract_count"),count("org_id_ex"))
    print "third parties count column"
    print third_parties_count.columns
    print "third parties count num"
    print third_parties_count.count()

    third_parties_users = third_parties.join(users, users.org_id_user == third_parties.third_org_id_user, "left")
    third_parties_users = third_parties_users.groupBy("third_org_id_user").count().withColumnRenamed("count", "user_count")
    final = third_parties_users.join(third_parties_count,third_parties_users.third_org_id_user==third_parties_count.third_org_id_user,"left")

    print "Total 3rd parties: "+str(final_count_3rd.count())+"/"+str(third_parties.count())
    print "----------final count-----------"



    
    temp = final_count_3rd.sample(False, 0.05, seed=0).limit(NUM).map(lambda x: x).collect()
    print ",".join(final_count_3rd.columns)
    for item in temp:
        item = map(str,item)
        print ",".join(item)
        
    
    
	


if __name__ == "__main__":

    # Configure Spark
    conf = SparkConf().setAppName(APP_NAME).set("spark.cores.max", "20")
    conf = conf.setMaster("spark://mapr-dev03.sncrbda.dev.vacum-np.sncrcorp.net:7077")
    sc    = SparkContext(conf=conf)

    # Execute Main functionality
    main(sc)
